package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthenticationOauth2ResourceServerKeycloakApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthenticationOauth2ResourceServerKeycloakApplication.class, args);
	}

}
